def find_middle_element(lst):
    return lst[len(lst)//2]

# Example usage:
my_list = [1, 2, 3, 4, 5]
middle_element = find_middle_element(my_list)
print("Middle element:", middle_element)