# Define the original string
original_string = "Hello, World!"

# Reverse the string using the slicing method
reversed_string = original_string[::-1]

# Print the reversed string
print(reversed_string)